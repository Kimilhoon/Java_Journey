package web.manager.dao.face;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ManagerDao {
	
	
	
}
