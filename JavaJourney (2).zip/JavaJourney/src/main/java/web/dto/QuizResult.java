package web.dto;

import lombok.Data;

@Data
public class QuizResult {

	private int quizResultNo;
	private int beanNo;
	private int grind;
	private int extraction;
	
} // class end
