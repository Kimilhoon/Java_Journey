package web.dto;

import lombok.Data;

@Data
public class BeanTaste {
//
	private int beanNo;
	private int cupNoteNo;
	
}
