package web.dto;

import lombok.Data;

@Data
public class EvenImg {
//
	private int eveImgNo;
	private String eveImgOriName;
	private String eveImgStorName;
	private int eveImgSize;
	
}
