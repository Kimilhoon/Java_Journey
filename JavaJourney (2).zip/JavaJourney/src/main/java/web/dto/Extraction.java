package web.dto;

import lombok.Data;

@Data
public class Extraction {
//
	private int extractionno;
	private String extractionname;
	
}
