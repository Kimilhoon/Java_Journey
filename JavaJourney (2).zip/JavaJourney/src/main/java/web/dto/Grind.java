package web.dto;

import lombok.Data;

@Data
public class Grind {

	private int grindNo;
	private String grindName;
	
} // class end
