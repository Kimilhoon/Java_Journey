package web.service.face;

public interface QuizService {
	
	
	
}
