package web.manager.service.face;

public interface ManagerService {
	
	
	
}
