package web.dto;

import lombok.Data;

@Data
public class Bean {
//
	private int beanNo;
	private int beanImgNo;
	private String beanName;
	private String origin;
	private String beanComm;
	private String beanInfo;
	private int beanPrice;
	private int businessNo;	
	
}
