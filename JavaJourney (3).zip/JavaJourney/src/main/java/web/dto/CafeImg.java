package web.dto;

import lombok.Data;

@Data
public class CafeImg {
//	
	private int cafeImgNo;
	private String cafeImgOriName;
	private String cafeImgStoName;
	private int cafeImgSize;

}
