package web.dto;

import lombok.Data;

@Data
public class CupNote {

	private int cupNoteNo;
	private String cupNoteName;
	
} // class end
