package web.service.face;

public interface MypageService {
	
	
	
}
