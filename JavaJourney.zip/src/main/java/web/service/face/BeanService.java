package web.service.face;

public interface BeanService {
	
	
	
}
