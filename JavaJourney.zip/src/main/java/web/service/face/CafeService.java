package web.service.face;

public interface CafeService {
	
	
	
}
