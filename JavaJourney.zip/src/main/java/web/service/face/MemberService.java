package web.service.face;

public interface MemberService {
	
	
	
}
