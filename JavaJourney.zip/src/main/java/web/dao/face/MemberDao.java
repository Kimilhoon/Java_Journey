package web.dao.face;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MemberDao {
	
	
	
}
