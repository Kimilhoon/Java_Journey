package web.dto;

import lombok.Data;

@Data
public class FreeBoardRecommend {

	private int freeBoardNo;
	private int userNo;
	
} // class end
