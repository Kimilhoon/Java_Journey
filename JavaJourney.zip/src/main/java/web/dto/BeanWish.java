package web.dto;

import lombok.Data;

@Data
public class BeanWish {
//	
	private int beanWishNo;
	private int beanNo;
	private int userNo;

}
