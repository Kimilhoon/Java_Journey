package web.dto;

import lombok.Data;

@Data
public class BeanImg {
//
	private int beanImgNo;
	private String beanOriginName;
	private String beanStoredName;
	private int beanImgSize;

}
