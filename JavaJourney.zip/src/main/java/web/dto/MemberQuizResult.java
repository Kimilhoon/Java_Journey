package web.dto;

import lombok.Data;

@Data
public class MemberQuizResult {

	private int quizResult;
	private int userNo;
	
} // class end
