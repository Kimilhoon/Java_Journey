package web.dto;

import lombok.Data;

@Data
public class MyRecipeRecommend {

	private int myRipNo;
	private int userNo;
	
} // class end
