package web.dto;

import lombok.Data;

@Data
public class MyRecipeImg {
	
	private int myRipImgNo;
	private String myRipImgOriname;
	private String myRipImgStoname;
	private int myRipImgSize;

} // class end
