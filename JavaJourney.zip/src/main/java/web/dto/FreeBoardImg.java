package web.dto;

import lombok.Data;

@Data
public class FreeBoardImg {

	private int freeImgNo;
	private String freeImgOriname;
	private String freeImgStoname;
	private int freeImgSize;
	
} // class end 
