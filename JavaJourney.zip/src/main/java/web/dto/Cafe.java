package web.dto;

import lombok.Data;

@Data
public class Cafe {
//
	private int cafeNo;
	private int imgNo;
	private String cafeName;
	private String cafeComm;
	private String cafePhone;
	private String busyTime;
	private String cafeLoc;
	private String cafeAdd1;
	private String cafeAdd2;
	
}
